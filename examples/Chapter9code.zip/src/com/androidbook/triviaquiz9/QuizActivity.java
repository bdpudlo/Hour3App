package com.androidbook.triviaquiz9;

import android.app.Activity;

public class QuizActivity extends Activity {

    public static final String GAME_PREFERENCES = "GamePrefs";

    public static final String DEBUG_TAG = "Trivia Quiz Log";
}