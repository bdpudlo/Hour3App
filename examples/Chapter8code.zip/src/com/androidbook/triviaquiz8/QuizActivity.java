package com.androidbook.triviaquiz8;

import android.app.Activity;

public class QuizActivity extends Activity {

    public static final String GAME_PREFERENCES = "GamePrefs";
}